# GTNH Faithful Textures
By Ethryan


Link to the forum
https://www.gtnewhorizons.com/forum/m/36844562/viewthread/32992999-ethryans-faithful-x32-new-horizons-itempack-version-2080

Link to Github
https://github.com/Ethryan/GTNH-Faithful-Textures

### Credits:
Credits to Magnetanide for her excellent block textures from the pack [Stellar Fusion](https://www.gtnewhorizons.com/forum/m/36844562/viewthread/32547244-stellar-fusion-gregtech-32x32-v034)
