# GTNHReflections
Provides specular maps for most blocks in GregTech: New Horizons

![image](https://github.com/S4mpsa/GTNHReflections/assets/69092953/657d829a-2f6e-4909-8b81-e880b4a0d18f)


Specular maps are generated from the textures with the function: `Reflectivity = (R + G + B) / 4`
